// 1.1 Basic Operations

5 + 5
5 - 2
11 * 11
5 % 2       // Remainder

// 1.2 Store Values use let (constant) and var

var clientNumber = 9173620497
var clientName = "Bob"
var clientGPA = 3.85

print(clientGPA)

let number: Double = 123

clientGPA = 4.00

var newNumber = (clientNumber + Int(number))
clientGPA + number

// Ex) Tip calcualator

var foodPrice: Double = 199
var tipPercent: Double = 0.20

var totalPrice = foodPrice + (foodPrice * tipPercent)

print(totalPrice)
